package com.example.currread.Utils;

import android.annotation.SuppressLint;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.Cursor;
import android.content.ContentValues;

import androidx.annotation.Nullable;
import com.example.currread.Model.crModel;

import java.util.ArrayList;
import java.util.List;
public class DataBase extends SQLiteOpenHelper {

    private SQLiteDatabase db;

    private static  final String DATABASE_NAME = "CR_DATABASE";
    private static  final String TABLE_NAME = "CR_TABLE";
    private static  final String COL_1 = "ID";
    private static  final String COL_2 = "JUDUL";
    private static  final String COL_3 = "STATUS";
    private static  final String COL_4 = "TOCHAP";
    private static  final String COL_5 = "CURCHAP";
    private static  final String COL_6 = "ALUR";
    private static  final String COL_7 = "BURL";
    private static  final String COL_8 = "VALID";
    public DataBase(@Nullable Context context) {
        super(context, DATABASE_NAME, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE IF NOT EXISTS " + TABLE_NAME + "(ID INTEGER PRIMARY KEY AUTOINCREMENT , JUDUL TEXT , STATUS TEXT, TOCHAP INTEGER, CURCHAP INTEGER, ALUR TEXT,BURL TEXT, VALID INTEGER)");
    }
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }

    public void insertItem(crModel model){
        db = this.getWritableDatabase();
            ContentValues values = new ContentValues();
            values.put(COL_2 , model.getJudul());
            values.put(COL_3 , model.getStatus());
            values.put(COL_4 , model.getTochap());
            values.put(COL_5 , model.getCurchap());
            values.put(COL_6 , model.getAlur());
            values.put(COL_7 , model.getBurl());
            values.put(COL_8 , 0);
            db.insert(TABLE_NAME , null , values);
    }
    public void updateJudul(int id ,String judul){
        db = this.getWritableDatabase();
            ContentValues values = new ContentValues();
            values.put(COL_2 , judul);
            db.update(TABLE_NAME , values , "ID=?" , new String[]{String.valueOf(id)});
    }
    public void updateStatus(int id , String status){
       db = this.getWritableDatabase();
            ContentValues values = new ContentValues();
            values.put(COL_3 , status);
            db.update(TABLE_NAME , values , "ID=?" , new String[]{String.valueOf(id)});
    }

    public void updateTochap(int id , int tochap){
         db = this.getWritableDatabase();
            ContentValues values = new ContentValues();
            values.put(COL_4 , tochap);
            db.update(TABLE_NAME , values , "ID=?" , new String[]{String.valueOf(id)});
    }

    public void updateCurchap(int id , int curchap){
        db = this.getWritableDatabase();
            ContentValues values = new ContentValues();
            values.put(COL_5 , curchap);
            db.update(TABLE_NAME , values , "ID=?" , new String[]{String.valueOf(id)});
    }
    public void updateAlur(int id , String alur){
        db = this.getWritableDatabase();
            ContentValues values = new ContentValues();
            values.put(COL_6 , alur);
            db.update(TABLE_NAME , values , "ID=?" , new String[]{String.valueOf(id)});
    }
    public void updateBurl(int id , String  burl){
        db = this.getWritableDatabase();
            ContentValues values = new ContentValues();
            values.put(COL_7 , burl);
            db.update(TABLE_NAME , values , "ID=?" , new String[]{String.valueOf(id)});
    }
    public void updateValid(int id , int valid){
        db = this.getWritableDatabase();
            ContentValues values = new ContentValues();
            values.put(COL_8 , valid);
            db.update(TABLE_NAME , values , "ID=?" , new String[]{String.valueOf(id)});
    }
    public void deleteItem(int id ){
        db = this.getWritableDatabase();
        db.delete(TABLE_NAME , "ID=?" , new String[]{String.valueOf(id)});
    }

    @SuppressLint("Range")
    public List<crModel> getAllTasks() {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = null;
        List<crModel> modelList = new ArrayList<>();
        db.beginTransaction();
        try {
            cursor = db.query(TABLE_NAME, null, null, null, null, null, null);
            if(cursor != null){
                if(cursor.moveToFirst()){
                    do {
                        crModel task = new crModel();
                        task.setId(cursor.getInt(cursor.getColumnIndex(COL_1)));
                        task.setJudul(cursor.getString(cursor.getColumnIndex(COL_2)));
                        task.setStatus(cursor.getString(cursor.getColumnIndex(COL_3)));
                        task.setTochap(cursor.getInt(cursor.getColumnIndex(COL_4)));
                        task.setCurchap(cursor.getInt(cursor.getColumnIndex(COL_5)));
                        task.setAlur(cursor.getString(cursor.getColumnIndex(COL_6)));
                        task.setBurl(cursor.getString(cursor.getColumnIndex(COL_7)));
                        task.setValid(cursor.getInt(cursor.getColumnIndex(COL_8)));
                        modelList.add(task);
                    } while (cursor.moveToNext());
                }
            }
        } finally {
            db.endTransaction();
            cursor.close();
        }
        return modelList;
    }
}
