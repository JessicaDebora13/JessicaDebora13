// toggle class active hamburger menu
const menuBar = document.querySelector('.menu-bar');
//toggle class active search
// ketika hamburger menu diklik
document.querySelector('#hamburger_menu').onclick = () => {
    menuBar.classList.toggle('active');
};
const searchForm = document.querySelector('.search_form');
const searchBox = document.querySelector('#search-box');
// ketika search-button diklik
document.querySelector('#search-button').onclick = () => {
    searchForm.classList.toggle('active');
    searchBox.focus();
};
//klik diluar elemen
const hm = document.querySelector('#hamburger_menu');
const sb = document.querySelector('#search-button');

document.addEventListener('click', function(e) {
    if(!hm.contains(e.target) && !menuBar.contains(e.target)){
        menuBar.classList.remove('active');
    }
    if(!sb.contains(e.target) && !searchForm.contains(e.target)){
        searchForm.classList.remove('active');
    }
});

function angka(e) {
    if (!/^[0-9]+$/.test(e.value)) {
       e.value = e.value.substring(0,e.value.length-1);
    }
 }

 function val(event) {
    event.preventDefault();
    let name = document.getElementById("name");
    let email = document.getElementById("email");
    let phone = document.getElementById("phone");
    let option = document.getElementById("option");
    let date = document.getElementById("dob");
    let newslatter = document.getElementById("newslatter");

    if (name.value === "") {
        alert("Name must be filled!");
        return false;
    } else if (name.value.length <= 5) {
        alert("Name must be more than just five characters!");
        return false;
    } else if (email.value === "") {
        alert("Email must be filled!");
        return false;
    } else if (!email.value.endsWith("@gmail.com")) {
        alert("The content must be an email address format!");
        return false;
    } else if (date.value === "") {
        alert("Date must be filled!");
        return false;
    } else if (phone.value === "") {
        alert("Number must be filled!");
        return false;
    } else if (!phone.value.startsWith("62")) {
        alert("Please use 62 at first!");
        return false;
    } else if (option.selectedIndex < 1) {
        alert("Please kindly choose one of the options!");
        return false;
    } else if (!newslatter.checked) {
        alert("The checkbox must be agreed!");
        return false;
    } else {
        alert("Data has been saved successfully!");
        return true;
    }
}

